# Angel's Font

## Selya's Gratitude

With sincere gratitude for choosing Angel's Font, we are honored by Her Majesty Selya’s blessing ~ one of her divine mirror stigmata creations, bestowed upon us.

## What is a Stigmata Mirror?

A Stigmata Mirror is a creation of Selya, the Divine Seamstress of Realities. This mirror represents a fragment of reality itself. The more pieces you assemble, the larger the image becomes. What the full image reveals is a reflection of time, beauty, and your own place within it ~ a living, evolving part of the world. 

SELYA is the embodiment of light, the CREATION serves as the mirror, and YOU are its reflection.

## This Stigmata Mirror Features

* **Multiple Fonts in One** – offers a continuously expanding variety of fonts, each with its own character and traits.
* **Options Support** – offers **per-font** customization.
* **Ink Design** – gives writing on books and other materials the appearance of quill-and-ink handwriting.
* **Stylish** – visually appealing, easy to read, and effortlessly clear.
* **Unicode Symbols** – seamlessly integrated with the surrounding letterforms for a unified aesthetic.
* **DGS Edition** – specialized Edition made for very dark GUI resource-packs.

## Language Support

* **English**  - Complete
* **Russian**  - Complete
* **Greek**    - Complete
* **Turkish**  - Complete
* **Ukrainian** - Complete
* **Spanish** - Complete
* **Chinese**  - Planned
* **Japanese** - Planned
* **Korean**   - Planned

## Need Help?
Should you encounter any issues, require language support, or wish to share suggestions, you are warmly invited to join our Discord server.
https://discord.gg/t7JJPyxJ6k

## Donations?

Ko-Fi:
https://ko-fi.com/liminalangel


~ May all the beauty be blessed, with you counted among its radiance.